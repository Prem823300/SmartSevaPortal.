import React, { useState, useEffect } from 'react';
import API from './api';
import axios from 'axios';

function App(){
  const [user, setUser] = useState(null);
  const [services, setServices] = useState([]);
  const [wallet, setWallet] = useState(null);

  useEffect(()=>{ loadServices(); },[]);

  async function loadServices(){
    const r = await API.get('/api/services');
    setServices(r.data.services || []);
  }

  async function login(){
    const phone = prompt('Phone: (for demo use any)');
    const password = prompt('Password (for demo register first via Register):');
    if (!phone || !password) return;
    try {
      const res = await API.post('/api/auth/login', { phone, password });
      setUser(res.data.user);
      setWallet(res.data.wallet);
      alert('Logged in: ' + res.data.user.name);
    } catch(e){
      alert(e.response?.data?.error || 'Error');
    }
  }

  async function register(){
    const name = prompt('Name:');
    const phone = prompt('Phone:');
    const password = prompt('Password:');
    if (!name || !phone || !password) return;
    try {
      const r = await API.post('/api/auth/register', { name, phone, password });
      alert('Registered. Token received.');
    } catch(e){ alert(e.response?.data?.error || 'Error'); }
  }

  async function topup(){
    if (!user) return alert('Login first');
    const amt = parseInt(prompt('Amount (min 100):', '100'), 10);
    if (!amt) return;
    try {
      const orderRes = await API.post('/api/wallet/topup/create-order', { user_id: user.id, amount: amt });
      const order = orderRes.data.order;
      // open Razorpay checkout
      const options = {
        key: process.env.REACT_APP_RAZORPAY_KEY || 'rzp_test_xxxxxxx',
        amount: order.amount,
        currency: order.currency,
        name: 'SmartSeva Portal',
        order_id: order.id,
        handler: async function(response){
          try {
            const verify = await API.post('/api/wallet/topup/verify', response);
            alert('Topup success ₹' + verify.data.amount);
            const w = await API.get(`/api/wallet/${user.id}`);
            setWallet(w.data.wallet);
          } catch(e){ alert('verify failed'); }
        },
        prefill: { name: user.name, contact: user.phone },
        theme: { color: '#2c6fbf' }
      };
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch(e){ alert(e.response?.data?.error || 'Error'); }
  }

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h3>SmartSeva Portal</h3>
        <div>
          {!user ? <>
            <button className="btn btn-primary me-2" onClick={login}>Login</button>
            <button className="btn btn-outline-primary" onClick={register}>Register</button>
          </> : <>
            <span className="me-3">Hi, {user.name} • ₹{wallet?.balance || 0}</span>
            <button className="btn btn-success me-2" onClick={topup}>Topup Wallet</button>
            <button className="btn btn-secondary" onClick={()=>{ setUser(null); setWallet(null); }}>Logout</button>
          </>}
        </div>
      </div>

      <div className="row">
        {services.map(s=>(
          <div className="col-6 col-md-4 col-lg-3 mb-3" key={s.id}>
            <div className="card p-3 shadow-sm">
              <img src={'/assets/'+(s.icon||'placeholder.png')} onError={(e)=>e.target.src='https://via.placeholder.com/64'} width="64" height="64" alt={s.title}/>
              <h6 className="mt-2">{s.title}</h6>
              <p>₹ {s.price}</p>
              <button className="btn btn-sm btn-primary" onClick={()=>alert('Perform service not implemented in demo')}>Perform</button>
            </div>
          </div>
        ))}
      </div>

      <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    </div>
  );
}

export default App;
