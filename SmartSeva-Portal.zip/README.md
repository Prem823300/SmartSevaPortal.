# SmartSeva Portal (Local ZIP)

This archive contains a ready-to-run **SmartSeva Portal** MVP:
- Backend: Node.js + Express + SQLite (better-sqlite3) with Razorpay integration (test mode).
- Frontend: React minimal app (CRA style) with basic UI.

## Important defaults (set by you)
- Admin email: prem@gmail.com
- Admin password: Prem@8233
- Minimum topup amount: ₹100

## Setup

### Backend
1. Open terminal:
```
cd SmartSeva-Portal/server
npm install
cp .env.example .env
# Edit .env: set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET
npm run dev
```
Server will run at http://localhost:4000

### Frontend
```
cd SmartSeva-Portal/client
npm install
npm start
```
Open: http://localhost:3000

## Notes
- Put Razorpay TEST keys in server/.env before testing payments.
- Admin simple login via /api/admin/login (email/password).
- This is an MVP. For production add input validation, HTTPS, secure secret storage, rate-limiting.

