const Database = require('better-sqlite3');
const db = new Database('data.db');

// users
db.prepare(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  phone TEXT UNIQUE,
  password_hash TEXT,
  role TEXT DEFAULT 'user',
  email TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`).run();

// wallet
db.prepare(`
CREATE TABLE IF NOT EXISTS wallet (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  balance INTEGER DEFAULT 0,
  FOREIGN KEY(user_id) REFERENCES users(id)
)`).run();

// services
db.prepare(`
CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE,
  title TEXT,
  price INTEGER DEFAULT 0,
  description TEXT,
  icon TEXT
)`).run();

// transactions
db.prepare(`
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  service_id INTEGER,
  type TEXT,
  amount INTEGER,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`).run();

// seed admin user and services
const admin = db.prepare('SELECT COUNT(*) as c FROM users WHERE email = ?').get('prem@gmail.com').c;
if (admin === 0) {
  const bcrypt = require('bcrypt');
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'Prem@8233', 10);
  const info = db.prepare('INSERT INTO users (name,phone,password_hash,role,email) VALUES (?,?,?,?,?)')
    .run('Admin','0000000000', hash, 'admin', 'prem@gmail.com');
  db.prepare('INSERT INTO wallet (user_id,balance) VALUES (?,?)').run(info.lastInsertRowid, 0);
}

const count = db.prepare('SELECT COUNT(*) as c FROM services').get().c;
if (count === 0) {
  const insert = db.prepare('INSERT INTO services (slug,title,price,description,icon) VALUES (?,?,?,?,?)');
  insert.run('recharge','Recharge Service',10,'Mobile recharge','recharge.png');
  insert.run('aadhaar','Aadhaar Services',25,'Aadhaar download via biometric','aadhaar.png');
  insert.run('pan','Pan Card Services',15,'PAN related services','pan.png');
  insert.run('vehicle','Vehicle Services',50,'Vehicle registration docs','vehicle.png');
  insert.run('ration','Ration Services',20,'Ration card services','ration.png');
  insert.run('voter','Voter Services',10,'Voter ID services','voter.png');
}

module.exports = db;
