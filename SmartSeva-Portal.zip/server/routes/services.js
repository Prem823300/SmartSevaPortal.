const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req,res)=>{
  const rows = db.prepare('SELECT * FROM services ORDER BY id').all();
  res.json({ services: rows });
});

router.get('/:slug', (req,res)=>{
  const s = db.prepare('SELECT * FROM services WHERE slug = ?').get(req.params.slug);
  if (!s) return res.status(404).json({ error:'not found' });
  res.json({ service: s });
});

module.exports = router;
