const express = require('express');
const router = express.Router();
const db = require('../db');
const Razorpay = require('razorpay');
const crypto = require('crypto');

const razor = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

router.get('/:userId', (req,res)=>{
  const w = db.prepare('SELECT * FROM wallet WHERE user_id = ?').get(req.params.userId);
  if (!w) return res.status(404).json({ error:'wallet not found' });
  res.json({ wallet: w });
});

// create order
router.post('/topup/create-order', async (req,res)=>{
  const { user_id, amount } = req.body;
  if (!user_id || !amount) return res.status(400).json({ error:'user_id & amount required' });
  const minTop = parseInt(process.env.MIN_TOPUP || '100', 10);
  if (amount < minTop) return res.status(400).json({ error: `minimum topup is ₹${minTop}` });
  const options = {
    amount: amount * 100,
    currency: "INR",
    receipt: `rcpt_${Date.now()}`,
    notes: { user_id: String(user_id) }
  };
  try {
    const order = await razor.orders.create(options);
    res.json({ order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'razorpay error' });
  }
});

// verify
router.post('/topup/verify', (req,res)=>{
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  const generated_signature = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(razorpay_order_id + "|" + razorpay_payment_id)
    .digest('hex');
  if (generated_signature !== razorpay_signature) {
    return res.status(400).json({ error:'invalid signature' });
  }
  razor.orders.fetch(razorpay_order_id).then(order => {
    const amount_rupee = order.amount / 100;
    const user_id = parseInt(order.notes.user_id, 10);
    db.prepare('UPDATE wallet SET balance = balance + ? WHERE user_id = ?').run(amount_rupee, user_id);
    db.prepare('INSERT INTO transactions (user_id, service_id, type, amount, description) VALUES (?,?,?,?,?)')
      .run(user_id, null, 'credit', amount_rupee, `Topup via Razorpay ${razorpay_payment_id}`);
    res.json({ success:true, amount: amount_rupee });
  }).catch(err=>{
    console.error(err); res.status(500).json({ error:'order fetch error' });
  });
});

module.exports = router;
