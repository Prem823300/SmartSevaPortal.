const express = require('express');
const router = express.Router();
const db = require('../db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const JWT_SECRET = process.env.JWT_SECRET || 'smartseva_jwt_secret';

// register
router.post('/register', async (req,res)=>{
  const { name, phone, password, email } = req.body;
  if (!name || !phone || !password) return res.status(400).json({ error:'name, phone, password required' });
  const existing = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
  if (existing) return res.status(400).json({ error: 'phone already registered' });
  const hash = await bcrypt.hash(password, 10);
  const info = db.prepare('INSERT INTO users (name, phone, password_hash, email) VALUES (?,?,?,?)').run(name, phone, hash, email || null);
  db.prepare('INSERT INTO wallet (user_id,balance) VALUES (?,?)').run(info.lastInsertRowid, 0);
  const user = db.prepare('SELECT id,name,phone,role,email,created_at FROM users WHERE id = ?').get(info.lastInsertRowid);
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET);
  res.json({ user, token });
});

// login
router.post('/login', async (req,res)=>{
  const { phone, password } = req.body;
  if (!phone || !password) return res.status(400).json({ error:'phone & password required' });
  const user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
  if (!user) return res.status(404).json({ error: 'user not found' });
  const ok = await bcrypt.compare(password, user.password_hash || '');
  if (!ok) return res.status(401).json({ error:'invalid credentials' });
  const u = { id: user.id, name: user.name, phone: user.phone, role: user.role, email: user.email };
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  const wallet = db.prepare('SELECT * FROM wallet WHERE user_id = ?').get(user.id);
  res.json({ user: u, token, wallet });
});

module.exports = router;
