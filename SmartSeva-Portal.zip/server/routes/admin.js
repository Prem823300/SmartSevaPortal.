const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcrypt');

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'prem@gmail.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Prem@8233';

// admin login (demo)
router.post('/login', (req,res)=>{
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error:'email & password required' });
  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    return res.json({ admin: { email }, token: 'admin-demo-token' });
  }
  res.status(401).json({ error: 'invalid' });
});

// list users
router.get('/users', (req,res)=>{
  const users = db.prepare('SELECT id,name,phone,email,role,created_at FROM users ORDER BY id DESC').all();
  res.json({ users });
});

// adjust wallet
router.post('/wallet/adjust', (req,res)=>{
  const { user_id, amount, type, description } = req.body;
  if (!user_id || !amount || !type) return res.status(400).json({ error:'user_id, amount, type required' });
  if (type === 'credit') {
    db.prepare('UPDATE wallet SET balance = balance + ? WHERE user_id = ?').run(amount, user_id);
  } else {
    db.prepare('UPDATE wallet SET balance = balance - ? WHERE user_id = ?').run(amount, user_id);
  }
  db.prepare('INSERT INTO transactions (user_id, service_id, type, amount, description) VALUES (?,?,?,?,?)')
    .run(user_id, null, type, amount, description || 'admin adjustment');
  res.json({ success:true });
});

// transactions
router.get('/transactions', (req,res)=>{
  const rows = db.prepare('SELECT t.*, u.name as user_name FROM transactions t LEFT JOIN users u ON u.id = t.user_id ORDER BY t.id DESC LIMIT 200').all();
  res.json({ transactions: rows });
});

module.exports = router;
